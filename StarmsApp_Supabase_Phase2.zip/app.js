// StarmsApp Supabase Phase 2 starter
// Replace the existing app.js with this file after config.js contains the correct Project URL and sb_publishable key.
// Required Supabase SQL is in supabase-schema.sql.
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const cfg = window.STARMS_CONFIG || {};
const url = cfg.SUPABASE_URL;
const key = cfg.SUPABASE_ANON_KEY;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let supabase = null, currentUser = null, selectedUser = null, channel = null;
let profile = null;

function showMessage(message) {
  const old = $('#starmsNotice'); if (old) old.remove();
  const n = document.createElement('div'); n.id = 'starmsNotice';
  n.style.cssText = 'position:fixed;z-index:99999;left:12px;right:12px;top:12px;background:#222;color:#fff;padding:14px;border:1px solid #d4af37;border-radius:12px;font:14px sans-serif;white-space:pre-wrap';
  n.textContent = message; document.body.appendChild(n);
  setTimeout(() => n.remove(), 6000);
}
function ensureAuthPanel() {
  if ($('#starmsAuth')) return;
  const panel = document.createElement('section'); panel.id='starmsAuth';
  panel.style.cssText='position:fixed;z-index:9999;inset:0;background:#090909;color:#fff;display:flex;align-items:center;justify-content:center;padding:20px;font-family:system-ui,sans-serif';
  panel.innerHTML = `<div style="max-width:420px;width:100%;background:#171717;border:1px solid #806c20;border-radius:18px;padding:22px">
  <h2 style="margin-top:0;color:#e0bd36">★ StarmsApp</h2><p>Jisajili au ingia ili kutumia StarmsApp kwenye vifaa mbalimbali.</p>
  <label>Jina la kuonyesha</label><input id="saName" placeholder="Mfano: Amina" style="box-sizing:border-box;width:100%;padding:12px;margin:6px 0 12px;border-radius:8px">
  <label>Barua pepe</label><input id="saEmail" type="email" placeholder="you@example.com" style="box-sizing:border-box;width:100%;padding:12px;margin:6px 0 12px;border-radius:8px">
  <label>Nenosiri (angalau herufi 6)</label><input id="saPassword" type="password" minlength="6" placeholder="Nenosiri" style="box-sizing:border-box;width:100%;padding:12px;margin:6px 0 14px;border-radius:8px">
  <div style="display:flex;gap:8px"><button id="saSignup" style="flex:1;padding:12px;background:#d4af37;border:0;border-radius:8px;font-weight:bold">Jisajili</button><button id="saLogin" style="flex:1;padding:12px;background:#333;color:white;border:0;border-radius:8px">Ingia</button></div>
  <p id="saHelp" style="font-size:13px;color:#ccc"></p></div>`;
  document.body.appendChild(panel);
  $('#saSignup').onclick = async () => {
    const email=$('#saEmail').value.trim(), password=$('#saPassword').value, name=$('#saName').value.trim() || email.split('@')[0];
    if (!email || password.length<6) return $('#saHelp').textContent='Weka email sahihi na nenosiri lenye angalau herufi 6.';
    const {error}=await supabase.auth.signUp({email,password,options:{data:{display_name:name}}});
    $('#saHelp').textContent=error ? error.message : 'Usajili umetumwa. Ikiwa email confirmation imewashwa, fungua email yako uthibitishe, kisha ingia.';
  };
  $('#saLogin').onclick = async () => {
    const {error}=await supabase.auth.signInWithPassword({email:$('#saEmail').value.trim(),password:$('#saPassword').value});
    $('#saHelp').textContent=error ? error.message : 'Umeingia...';
    if (!error) await startApp();
  };
}
function removeAuthPanel(){ $('#starmsAuth')?.remove(); }
async function ensureProfile() {
  const name=currentUser.user_metadata?.display_name || currentUser.email?.split('@')[0] || 'Starms user';
  const {data,error}=await supabase.from('profiles').upsert({id:currentUser.id,display_name:name}, {onConflict:'id'}).select().single();
  if(error) throw error; profile=data;
}
function addChatUI() {
  if ($('#starmsChatPanel')) return;
  const panel=document.createElement('div'); panel.id='starmsChatPanel';
  panel.style.cssText='position:fixed;z-index:9998;inset:0;background:#090909;color:white;display:none;flex-direction:column;font-family:system-ui,sans-serif';
  panel.innerHTML=`<header style="padding:14px;display:flex;align-items:center;gap:10px;border-bottom:1px solid #333"><button id="scBack">‹</button><b id="scTitle">Mazungumzo</b><button id="scLogout" style="margin-left:auto">Toka</button></header>
  <div id="scPeople" style="overflow:auto;padding:10px;border-bottom:1px solid #333;max-height:30vh"></div>
  <div id="scMessages" style="flex:1;overflow:auto;padding:12px"></div>
  <form id="scForm" style="display:flex;gap:8px;padding:10px;border-top:1px solid #333"><input id="scInput" placeholder="Andika ujumbe..." style="flex:1;min-width:0;padding:12px;border-radius:10px"><button style="padding:12px;background:#d4af37;border:0;border-radius:10px">Tuma</button></form>`;
  document.body.appendChild(panel);
  $('#scBack').onclick=()=>{panel.style.display='none';};
  $('#scLogout').onclick=async()=>{await supabase.auth.signOut();location.reload();};
  $('#scForm').onsubmit=async e=>{
    e.preventDefault(); if(!selectedUser) return showMessage('Chagua mtu kwenye orodha kwanza.');
    const body=$('#scInput').value.trim(); if(!body) return;
    const {error}=await supabase.from('messages').insert({sender_id:currentUser.id,recipient_id:selectedUser.id,body});
    if(error) showMessage('Ujumbe haukutumwa: '+error.message); else $('#scInput').value='';
    await loadMessages();
  };
}
async function loadPeople() {
  const {data,error}=await supabase.from('profiles').select('id,display_name').neq('id',currentUser.id).order('display_name');
  if(error) { showMessage('Kushindwa kupata watumiaji. Angalia SQL/RLS: '+error.message); return; }
  const box=$('#scPeople'); box.innerHTML='';
  if(!data.length) box.textContent='Hakuna watumiaji wengine bado. Mtu mwingine ajisajili kwanza.';
  data.forEach(p=>{
    const b=document.createElement('button'); b.textContent=p.display_name || 'Mtumiaji';
    b.style.cssText='display:block;width:100%;text-align:left;padding:12px;margin:4px 0;background:#222;color:white;border:1px solid #444;border-radius:10px';
    b.onclick=async()=>{selectedUser=p;$('#scTitle').textContent=p.display_name || 'Mazungumzo';await loadMessages();};
    box.appendChild(b);
  });
}
async function loadMessages() {
  if(!selectedUser) return;
  const {data,error}=await supabase.from('messages').select('id,sender_id,recipient_id,body,created_at').or(`and(sender_id.eq.${currentUser.id},recipient_id.eq.${selectedUser.id}),and(sender_id.eq.${selectedUser.id},recipient_id.eq.${currentUser.id})`).order('created_at');
  if(error) { showMessage('Imeshindikana kusoma ujumbe: '+error.message); return; }
  const box=$('#scMessages'); box.innerHTML='';
  data.forEach(m=>{const d=document.createElement('div');d.textContent=(m.sender_id===currentUser.id?'Mimi: ':'Yeye: ')+m.body;d.style.cssText='padding:10px;margin:7px 0;max-width:90%;overflow-wrap:anywhere;background:'+(m.sender_id===currentUser.id?'#493e12':'#252525')+';border-radius:12px';box.appendChild(d);});
  box.scrollTop=box.scrollHeight;
}
async function startApp() {
  const {data}=await supabase.auth.getSession(); currentUser=data.session?.user;
  if(!currentUser){ensureAuthPanel();return;}
  try { await ensureProfile(); removeAuthPanel(); addChatUI(); $('#starmsChatPanel').style.display='flex'; await loadPeople();
    // Wire existing chat buttons to the real user list.
    if($('#newChat')) $('#newChat').onclick=async()=>{ $('#starmsChatPanel').style.display='flex'; await loadPeople(); };
    if($('#discoverBtn')) $('#discoverBtn').onclick=async()=>{ $('#starmsChatPanel').style.display='flex'; await loadPeople(); };
    $$('#chatList .row').forEach(el=>el.onclick=()=>showMessage('Fungua New chat (+) kuchagua mtumiaji halisi.'));
    if(channel) await supabase.removeChannel(channel);
    channel=supabase.channel('starms-messages-'+currentUser.id).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},payload=>{
      const m=payload.new;
      if(selectedUser && ((m.sender_id===selectedUser.id && m.recipient_id===currentUser.id)||(m.sender_id===currentUser.id && m.recipient_id===selectedUser.id))) loadMessages();
    }).subscribe();
  } catch(e){ showMessage('StarmsApp: '+(e.message||String(e))); }
}
if(!url || !key || key.includes('WEKA_')) {
  showMessage('config.js haijajazwa vizuri. Weka Project URL halisi na sb_publishable key.');
} else {
  supabase=createClient(url,key);
  startApp();
  supabase.auth.onAuthStateChange(()=>{setTimeout(startApp,0);});
}
