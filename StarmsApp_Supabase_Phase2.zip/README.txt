StarmsApp Supabase starter files

1. Replace the existing repository app.js with app.js from this package (do not upload as a differently named file; index.html loads app.js).
2. In Supabase Dashboard > SQL Editor > New query, paste and run supabase-schema.sql.
3. Confirm config.js has your exact Supabase Project URL and sb_publishable key.
4. In Supabase Authentication settings, choose whether to require email confirmation. For safer public use, leave confirmation on.
5. Wait for GitHub Pages to redeploy, then open the StarmsApp URL and test signup with two separate email accounts.

Important:
- This starter implements email/password signup/login and basic private direct text messages.
- It does NOT yet implement working voice/video calling, full status/followers/creator tools, password recovery, abuse reporting, or production moderation.
- Keep Secret keys private. Do not put them in browser code.
